package com.scotiabank.cache.core;

import java.util.LinkedHashMap;

import com.scotiabank.cache.utils.Constants;

public class Cache {

	private LinkedHashMap<Integer, CacheObject> cache;

	int cacheSize = Constants.CACHE_SIZE;
	long timeToLiveInSeconds = Constants.TIME_TO_LIVE_IN_SECONDS;
	
	public Cache(int cacheSize){
		this.cacheSize = cacheSize;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	public Cache(long timeToLiveInSeconds){
		this.timeToLiveInSeconds = timeToLiveInSeconds;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	public Cache(int cacheSize, long timeToLiveInSeconds){
		this.cacheSize = cacheSize;
		this.timeToLiveInSeconds = timeToLiveInSeconds;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	//======================================================
	//Get cached object from the cache
	//Update the last accessed timestamp
	//======================================================
	public CacheObject fetchFromCache(int primaryKey){
		CacheObject cacheObject = cache.get(primaryKey);
		cacheObject.setLastAccessedTimestamp(System.currentTimeMillis());
		return cacheObject;
	}
	
	//======================================================
	//Store the DB result in the cache.
	//Update the last accessed timestamp
	//======================================================
	public void storeInCache(int primaryKey, Object object){
		CacheObject cacheObject = new CacheObject();
		cacheObject.setObject(object);
		cacheObject.setLastAccessedTimestamp(System.currentTimeMillis());
		
		cache.put(primaryKey, cacheObject);
	}
	
	public int getSize(){
		return cache.size();
	}
	
	public void removeAllObjects(){
		cache.clear();
	}
}
