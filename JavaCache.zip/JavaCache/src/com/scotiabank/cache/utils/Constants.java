package com.scotiabank.cache.utils;

public class Constants {

	public static final String REF_COUNTRY = "REF_COUNTRY";
	public static final String REF_CURRENCY = "REF_CURRENCY";
	public static final String REF_HOLIDAY = "REF_HOLIDAY";
	
	public static final int CACHE_SIZE = 3;
	public static final long TIME_TO_LIVE_IN_SECONDS = 300;

	public static final int CLEANUP_INTERVAL_IN_SECONDS = 5;

}
