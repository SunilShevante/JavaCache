package com.scotiabank.dao.model;

import java.util.Date;

public class RefCurrencyObject {

	private int currencyId;
	private String currencyCode;
	private String currencyName;
	private String currencySymbol;
	private int statusInd;
	private Date lastModifiedDate;
	private int lastModifiedPerson;

	public int getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(int currencyId) {
		this.currencyId = currencyId;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getCurrencySymbol() {
		return currencySymbol;
	}

	public void setCurrencySymbol(String currencySymbol) {
		this.currencySymbol = currencySymbol;
	}

	public int getStatusInd() {
		return statusInd;
	}

	public void setStatusInd(int statusInd) {
		this.statusInd = statusInd;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getLastModifiedPerson() {
		return lastModifiedPerson;
	}

	public void setLastModifiedPerson(int lastModifiedPerson) {
		this.lastModifiedPerson = lastModifiedPerson;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RefCurrencyTable [currencyId=").append(currencyId)
				.append(", currencyCode=").append(currencyCode)
				.append(", currencyName=").append(currencyName)
				.append(", currencySymbol=").append(currencySymbol)
				.append(", statusInd=").append(statusInd)
				.append(", lastModifiedDate=").append(lastModifiedDate)
				.append(", lastModifiedPerson=").append(lastModifiedPerson)
				.append("]");
		return builder.toString();
	}

}
