package com.scotiabank.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.scotiabank.dao.model.RefCurrencyObject;

public class RefCurrencyDAO {
	
	private static Map<Integer, RefCurrencyObject> prefilledSampleData = new HashMap<>();

	public static RefCurrencyObject getRefCurrencyObject(int currencyId) {
		return prefilledSampleData.get(currencyId);
	}

	static {
		RefCurrencyObject refCurrency1 = new RefCurrencyObject();
		refCurrency1.setCurrencyId(1);
		refCurrency1.setCurrencyCode("USD");
		refCurrency1.setCurrencyName("United States Dollar");
		refCurrency1.setCurrencySymbol("\\U0024");
		refCurrency1.setStatusInd(1);
		refCurrency1.setLastModifiedDate(new Date());
		refCurrency1.setLastModifiedPerson(6174);
		prefilledSampleData.put(1, refCurrency1);

		RefCurrencyObject refCurrency2 = new RefCurrencyObject();
		refCurrency2.setCurrencyId(44);
		refCurrency2.setCurrencyCode("GBP");
		refCurrency2.setCurrencyName("Great Britain Pound");
		refCurrency2.setCurrencySymbol("\\U00A3");
		refCurrency2.setStatusInd(44);
		refCurrency2.setLastModifiedDate(new Date());
		refCurrency2.setLastModifiedPerson(6174);
		prefilledSampleData.put(44, refCurrency2);

		RefCurrencyObject refCurrency3 = new RefCurrencyObject();
		refCurrency3.setCurrencyId(91);
		refCurrency3.setCurrencyCode("INR");
		refCurrency3.setCurrencyName("Indian Rupee");
		refCurrency3.setCurrencySymbol("\\U20B9");
		refCurrency3.setStatusInd(91);
		refCurrency3.setLastModifiedDate(new Date());
		refCurrency3.setLastModifiedPerson(6174);
		prefilledSampleData.put(91, refCurrency3);

		RefCurrencyObject refCurrency4 = new RefCurrencyObject();
		refCurrency4.setCurrencyId(61);
		refCurrency4.setCurrencyCode("AUD");
		refCurrency4.setCurrencyName("Australian Dollar");
		refCurrency4.setCurrencySymbol("\\U0024");
		refCurrency4.setStatusInd(61);
		refCurrency4.setLastModifiedDate(new Date());
		refCurrency4.setLastModifiedPerson(6174);
		prefilledSampleData.put(61, refCurrency4);

		RefCurrencyObject refCurrency5 = new RefCurrencyObject();
		refCurrency5.setCurrencyId(49);
		refCurrency5.setCurrencyCode("EUR");
		refCurrency5.setCurrencyName("Germany");
		refCurrency5.setCurrencySymbol("\\U20AC");
		refCurrency5.setStatusInd(49);
		refCurrency5.setLastModifiedDate(new Date());
		refCurrency5.setLastModifiedPerson(6174);
		prefilledSampleData.put(49, refCurrency5);

	}

}
