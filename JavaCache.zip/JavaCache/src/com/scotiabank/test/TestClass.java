package com.scotiabank.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.scotiabank.cache.core.CacheManager;
import com.scotiabank.cache.utils.Constants;
import com.scotiabank.dao.RefCountryDAO;
import com.scotiabank.dao.model.RefCountryObject;

public class TestClass {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void fetchRefCountry() {
		RefCountryObject refCountryObject = RefCountryDAO.getRefCountryObject(1);
		CacheManager.getInstance().storeInCache(Constants.REF_COUNTRY, 1, refCountryObject);
	}

}
