package com.scotiabank.dao.model;

import java.util.Date;

public class RefHolidayObject {

	private int holidayId;
	private String holidayCode;
	private String holidayName;
	private Date holidayDate;
	private int statusInd;
	private Date lastModifiedDate;
	private int lastModifiedPerson;

	public int getHolidayId() {
		return holidayId;
	}

	public void setHolidayId(int holidayId) {
		this.holidayId = holidayId;
	}

	public String getHolidayCode() {
		return holidayCode;
	}

	public void setHolidayCode(String holidayCode) {
		this.holidayCode = holidayCode;
	}

	public String getHolidayName() {
		return holidayName;
	}

	public void setHolidayName(String holidayName) {
		this.holidayName = holidayName;
	}

	public Date getHolidayDate() {
		return holidayDate;
	}

	public void setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
	}

	public int getStatusInd() {
		return statusInd;
	}

	public void setStatusInd(int statusInd) {
		this.statusInd = statusInd;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getLastModifiedPerson() {
		return lastModifiedPerson;
	}

	public void setLastModifiedPerson(int lastModifiedPerson) {
		this.lastModifiedPerson = lastModifiedPerson;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RefHolidayObject [holidayId=").append(holidayId)
				.append(", holidayCode=").append(holidayCode)
				.append(", holidayName=").append(holidayName)
				.append(", holidayDate=").append(holidayDate)
				.append(", statusInd=").append(statusInd)
				.append(", lastModifiedDate=").append(lastModifiedDate)
				.append(", lastModifiedPerson=").append(lastModifiedPerson)
				.append("]");
		return builder.toString();
	}

}
