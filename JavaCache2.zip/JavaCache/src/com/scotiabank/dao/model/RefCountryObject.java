package com.scotiabank.dao.model;

import java.util.Date;

public class RefCountryObject {

	private int countryId;
	private String countryCode;
	private String countryName;
	private int statusInd;
	private Date lastModifiedDate;
	private int lastModifiedPerson;

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public int getStatusInd() {
		return statusInd;
	}

	public void setStatusInd(int statusInd) {
		this.statusInd = statusInd;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getLastModifiedPerson() {
		return lastModifiedPerson;
	}

	public void setLastModifiedPerson(int lastModifiedPerson) {
		this.lastModifiedPerson = lastModifiedPerson;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RefCountryTable [countryId=").append(countryId)
				.append(", countryCode=").append(countryCode)
				.append(", countryName=").append(countryName)
				.append(", statusInd=").append(statusInd)
				.append(", lastModifiedDate=").append(lastModifiedDate)
				.append(", lastModifiedPerson=").append(lastModifiedPerson)
				.append("]");
		return builder.toString();
	}

}
