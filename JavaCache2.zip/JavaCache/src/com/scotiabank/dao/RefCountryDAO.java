package com.scotiabank.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.scotiabank.dao.model.RefCountryObject;

public class RefCountryDAO {

	private static Map<Integer, RefCountryObject> prefilledSampleData = new HashMap<>();

	public static RefCountryObject getRefCountryObject(int countryId) {
		return prefilledSampleData.get(countryId);
	}

	static {
		RefCountryObject refCountry1 = new RefCountryObject();
		refCountry1.setCountryId(1);
		refCountry1.setCountryCode("US");
		refCountry1.setCountryName("United States of America");
		refCountry1.setStatusInd(1);
		refCountry1.setLastModifiedDate(new Date());
		refCountry1.setLastModifiedPerson(6174);
		prefilledSampleData.put(1, refCountry1);

		RefCountryObject refCountry2 = new RefCountryObject();
		refCountry2.setCountryId(44);
		refCountry2.setCountryCode("GB");
		refCountry2.setCountryName("United Kingdom");
		refCountry2.setStatusInd(44);
		refCountry2.setLastModifiedDate(new Date());
		refCountry2.setLastModifiedPerson(6174);
		prefilledSampleData.put(44, refCountry2);

		RefCountryObject refCountry3 = new RefCountryObject();
		refCountry3.setCountryId(91);
		refCountry3.setCountryCode("IND");
		refCountry3.setCountryName("India");
		refCountry3.setStatusInd(91);
		refCountry3.setLastModifiedDate(new Date());
		refCountry3.setLastModifiedPerson(6174);
		prefilledSampleData.put(91, refCountry3);

		RefCountryObject refCountry4 = new RefCountryObject();
		refCountry4.setCountryId(61);
		refCountry4.setCountryCode("AU");
		refCountry4.setCountryName("Australia");
		refCountry4.setStatusInd(61);
		refCountry4.setLastModifiedDate(new Date());
		refCountry4.setLastModifiedPerson(6174);
		prefilledSampleData.put(61, refCountry4);

		RefCountryObject refCountry5 = new RefCountryObject();
		refCountry5.setCountryId(49);
		refCountry5.setCountryCode("DE");
		refCountry5.setCountryName("Germany");
		refCountry5.setStatusInd(49);
		refCountry5.setLastModifiedDate(new Date());
		refCountry5.setLastModifiedPerson(6174);
		prefilledSampleData.put(49, refCountry5);

	}

}
