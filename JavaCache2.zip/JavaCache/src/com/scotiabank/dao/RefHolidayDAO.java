package com.scotiabank.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.scotiabank.dao.model.RefHolidayObject;

public class RefHolidayDAO {
	
	private static Map<Integer, RefHolidayObject> prefilledSampleData = new HashMap<>();

	public static RefHolidayObject getRefHolidayObject(int holidayId) {
		return prefilledSampleData.get(holidayId);
	}

	static {
		RefHolidayObject refHoliday1 = new RefHolidayObject();
		refHoliday1.setHolidayId(1);
		refHoliday1.setHolidayCode("CD17");
		refHoliday1.setHolidayName("Columbus Day");
		refHoliday1.setHolidayDate(getDate(2017, 10, 9));
		refHoliday1.setStatusInd(1);
		refHoliday1.setLastModifiedDate(new Date());
		refHoliday1.setLastModifiedPerson(6174);
		prefilledSampleData.put(1, refHoliday1);

		RefHolidayObject refHoliday2 = new RefHolidayObject();
		refHoliday2.setHolidayId(2);
		refHoliday2.setHolidayCode("CH17");
		refHoliday2.setHolidayName("Christmas");
		refHoliday2.setHolidayDate(getDate(2017, 12, 25));
		refHoliday2.setStatusInd(2);
		refHoliday2.setLastModifiedDate(new Date());
		refHoliday2.setLastModifiedPerson(6174);
		prefilledSampleData.put(2, refHoliday2);

		RefHolidayObject refHoliday3 = new RefHolidayObject();
		refHoliday3.setHolidayId(3);
		refHoliday3.setHolidayCode("DIW17");
		refHoliday3.setHolidayName("Diwali");
		refHoliday3.setHolidayDate(getDate(2017, 10, 19));
		refHoliday3.setStatusInd(3);
		refHoliday3.setLastModifiedDate(new Date());
		refHoliday3.setLastModifiedPerson(6174);
		prefilledSampleData.put(3, refHoliday3);

		RefHolidayObject refHoliday4 = new RefHolidayObject();
		refHoliday4.setHolidayId(4);
		refHoliday4.setHolidayCode("US17");
		refHoliday4.setHolidayName("US Independence Day");
		refHoliday4.setHolidayDate(getDate(2017, 7, 4));
		refHoliday4.setStatusInd(4);
		refHoliday4.setLastModifiedDate(new Date());
		refHoliday4.setLastModifiedPerson(6174);
		prefilledSampleData.put(4, refHoliday4);

		RefHolidayObject refHoliday5 = new RefHolidayObject();
		refHoliday5.setHolidayId(5);
		refHoliday5.setHolidayCode("CAN17");
		refHoliday5.setHolidayName("Canada Independence Day");
		refHoliday5.setHolidayDate(getDate(2017, 7, 1));
		refHoliday5.setStatusInd(5);
		refHoliday5.setLastModifiedDate(new Date());
		refHoliday5.setLastModifiedPerson(6174);
		prefilledSampleData.put(5, refHoliday5);

	}
	
	private static Date getDate(int year, int month, int date){
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, (month - 1));
		c.set(Calendar.DAY_OF_MONTH, date);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		
		return c.getTime();
	}

}
