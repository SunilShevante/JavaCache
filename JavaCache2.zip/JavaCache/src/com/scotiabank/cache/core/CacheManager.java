package com.scotiabank.cache.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.scotiabank.cache.utils.Constants;
import com.scotiabank.dao.RefCountryDAO;

public class CacheManager {

	private static CacheManager cacheManager = new CacheManager();

	static {
		cleanUpCache();
	}

	//Private constructor
	private CacheManager(){
	}
	
	public static CacheManager getInstance() {
		return cacheManager;
	}

	// ======================================================
	//This map holds individual caches for all tables.
	//Key is the table name and value is the actual cache for the table.
	// ======================================================
	private static Map<String, Cache> cacheMap = new HashMap<>();

	// ======================================================
	// Create new cache for a DB table.
	// ======================================================
	public void addNewCache(String tableName, int cacheSize, long timeToLiveInSeconds) {
		System.out.println("Adding cache for table : " + tableName);
		if (cacheMap.get(tableName) != null) {
			System.err.println("Cache already exists for table name " + tableName);
			return;
		}

		Cache cache = new Cache(cacheSize, timeToLiveInSeconds);
		cache.setTableName(tableName);
		cacheMap.put(tableName, cache);
		System.out.println("Added cache for table : " + tableName);
	}

	// ======================================================
	// Delete existing cache for a DB table.
	// ======================================================
	public void deleteCache(String tableName) {
		System.out.println("Deleting cache for table : " + tableName);
		Cache cache = cacheMap.get(tableName);
		if (cache != null) {
			cache.removeAllObjects();
			cache = null;
		}
		cacheMap.remove(tableName);
		System.out.println("Deleted cache for table : " + tableName);
	}

	// ======================================================
	// Get cached object from a particular table cache
	// ======================================================
	public CacheObject fetchFromCache(String tableName, int primaryKey) {
		System.out.println("Fetching data from cache for table : " + tableName + " and primaryKey : " + primaryKey);
		Cache cache = cacheMap.get(tableName);
		if (cache != null) {
			return cache.fetchFromCache(primaryKey);
		}
		System.err.println("Either cache does not exist for the table or object is not present in cache!");
		return null;
	}

	// ======================================================
	// Store a DB result in the corresponding table cache.
	// ======================================================
	public void storeInCache(String tableName, int primaryKey, Object object) {
		System.out.println("Storing data to cache for table : " + tableName + " and primaryKey : " + primaryKey);
		Cache cache = cacheMap.get(tableName);
		if (cache != null) {
			cache.storeInCache(primaryKey, object);
			return;
		}
		System.err.println("Cache does not exist for the table! Please create the cache first!");
	}

	// ======================================================
	// The cleanup thread keeps on running periodically.
	// It will evict all expired cached entries.
	// ======================================================
	private static void cleanUpCache() {

		Thread t = new Thread() {
			public void run() {
				try {
					System.out.println("Starting the cleanup thread to run infinitely...\n");
					int executionCount = 0;
					while (true) {
						Thread.sleep(Constants.CLEANUP_INTERVAL_IN_SECONDS * 1000);

						executionCount++;
						
						//Iterate through all caches
						Set<String> tableNames = cacheMap.keySet();
						for(String tableName : tableNames){
							Cache cache = cacheMap.get(tableName);
							
							System.out.println("\n\nCleaning up cache for table : " + cache.getTableName());
							cache.evictExpiredEntries();
						}
						System.out.println("Cleanup thread completed! Execution #" + executionCount);
						printStatistics();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			};
		};
		t.setDaemon(true);
		t.start();
	}

	public static void printStatistics() {
		System.out.println("\n\n###############################################");
		System.out.println("               Cache Statistics                ");
		System.out.println("###############################################");
		System.out.println("Number of tables cached : " + cacheMap.size());

		Set<String> keys = cacheMap.keySet();
		for (String tableName : keys) {
			System.out.println("Cached entries for " + tableName + " : " + cacheMap.get(tableName).getSize());
		}

		System.out.println("###############################################");
	}

	public static void main(String[] args) {

		// System.out.println(RefCountryDAO.getRefCountryObject(1));
		// System.out.println(RefCountryDAO.getRefCountryObject(44));
		// System.out.println(RefCountryDAO.getRefCountryObject(49));
		// System.out.println(RefCountryDAO.getRefCountryObject(61));
		// System.out.println(RefCountryDAO.getRefCountryObject(91));
		//
		// System.out.println(RefCurrencyDAO.getRefCurrencyObject(1));
		// System.out.println(RefCurrencyDAO.getRefCurrencyObject(44));
		// System.out.println(RefCurrencyDAO.getRefCurrencyObject(49));
		// System.out.println(RefCurrencyDAO.getRefCurrencyObject(61));
		// System.out.println(RefCurrencyDAO.getRefCurrencyObject(91));
		//
		// System.out.println(RefHolidayDAO.getRefHolidayObject(1));
		// System.out.println(RefHolidayDAO.getRefHolidayObject(2));
		// System.out.println(RefHolidayDAO.getRefHolidayObject(3));
		// System.out.println(RefHolidayDAO.getRefHolidayObject(4));
		// System.out.println(RefHolidayDAO.getRefHolidayObject(5));

		// Add three basic caches
		cacheManager.addNewCache(Constants.REF_COUNTRY, 4, 300);
		cacheManager.addNewCache(Constants.REF_CURRENCY, 3, 300);
		cacheManager.addNewCache(Constants.REF_HOLIDAY, 5, 300);
		System.out.println();

		cacheManager.storeInCache(Constants.REF_COUNTRY, 1, RefCountryDAO.getRefCountryObject(1));
		cacheManager.storeInCache(Constants.REF_COUNTRY, 44, RefCountryDAO.getRefCountryObject(44));
		cacheManager.storeInCache(Constants.REF_COUNTRY, 49, RefCountryDAO.getRefCountryObject(49));
		cacheManager.storeInCache(Constants.REF_COUNTRY, 61, RefCountryDAO.getRefCountryObject(61));
		cacheManager.storeInCache(Constants.REF_COUNTRY, 91, RefCountryDAO.getRefCountryObject(91));
		System.out.println();

		cacheManager.storeInCache(Constants.REF_CURRENCY, 1, RefCountryDAO.getRefCountryObject(1));
		cacheManager.storeInCache(Constants.REF_CURRENCY, 44, RefCountryDAO.getRefCountryObject(44));
		cacheManager.storeInCache(Constants.REF_CURRENCY, 49, RefCountryDAO.getRefCountryObject(49));
		cacheManager.storeInCache(Constants.REF_CURRENCY, 61, RefCountryDAO.getRefCountryObject(61));
		cacheManager.storeInCache(Constants.REF_CURRENCY, 91, RefCountryDAO.getRefCountryObject(91));
		System.out.println();

		cacheManager.storeInCache(Constants.REF_HOLIDAY, 1, RefCountryDAO.getRefCountryObject(1));
		cacheManager.storeInCache(Constants.REF_HOLIDAY, 2, RefCountryDAO.getRefCountryObject(2));
		cacheManager.storeInCache(Constants.REF_HOLIDAY, 3, RefCountryDAO.getRefCountryObject(3));
		cacheManager.storeInCache(Constants.REF_HOLIDAY, 4, RefCountryDAO.getRefCountryObject(4));
		cacheManager.storeInCache(Constants.REF_HOLIDAY, 5, RefCountryDAO.getRefCountryObject(5));
		System.out.println();

		printStatistics();
		
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		CacheObject cacheObject = cacheManager.fetchFromCache(Constants.REF_COUNTRY, 91);
		if(cacheObject != null){
			System.out.println("Cached Object : " + cacheObject.getObject());
		}
		cacheObject = cacheManager.fetchFromCache(Constants.REF_COUNTRY, 1);
		if(cacheObject != null){
			System.out.println("Cached Object : " + cacheObject.getObject());
		}
		cacheObject = cacheManager.fetchFromCache(Constants.REF_CURRENCY, 91);
		if(cacheObject != null){
			System.out.println("Cached Object : " + cacheObject.getObject());
		}
		cacheObject = cacheManager.fetchFromCache(Constants.REF_HOLIDAY, 3);
		if(cacheObject != null){
			System.out.println("Cached Object : " + cacheObject.getObject());
		}
	}
}
