package com.scotiabank.test;

import java.util.Date;

import com.scotiabank.dao.model.RefCurrencyObject;

public class Test {

	public static void main(String[] args) {

		RefCurrencyObject refCurrency2 = new RefCurrencyObject();
		refCurrency2.setCurrencyId(44);
		refCurrency2.setCurrencyCode("GBP");
		refCurrency2.setCurrencyName("Great Britain Pound");
		refCurrency2.setCurrencySymbol("\\U00A3");
		refCurrency2.setStatusInd(44);
		refCurrency2.setLastModifiedDate(new Date());
		refCurrency2.setLastModifiedPerson(6174);
		
		System.out.println(refCurrency2);
	}

}
