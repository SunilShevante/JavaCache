package com.scotiabank.cache.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import com.scotiabank.cache.utils.Constants;

public class Cache {

	private String tableName;
	private LinkedHashMap<Integer, CacheObject> cache;
	private Object lock = new Object();

	int cacheSize = Constants.CACHE_SIZE;
	long timeToLiveInSeconds = Constants.TIME_TO_LIVE_IN_SECONDS;
	
	public Cache(int cacheSize){
		this.cacheSize = cacheSize;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	public Cache(long timeToLiveInSeconds){
		this.timeToLiveInSeconds = timeToLiveInSeconds;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	public Cache(int cacheSize, long timeToLiveInSeconds){
		this.cacheSize = cacheSize;
		this.timeToLiveInSeconds = timeToLiveInSeconds;
		cache = new LinkedHashMap<Integer, CacheObject>(cacheSize, 0.75f, true);
	}
	
	//======================================================
	//Get cached object from the cache
	//Update the last accessed timestamp
	//======================================================
	public CacheObject fetchFromCache(int primaryKey){
		CacheObject cacheObject = cache.get(primaryKey);
		cacheObject.setLastAccessedTimestamp(System.currentTimeMillis());
		return cacheObject;
	}
	
	//======================================================
	//Store the DB result in the cache.
	//Update the last accessed timestamp
	//======================================================
	public void storeInCache(int primaryKey, Object object){
		CacheObject cacheObject = new CacheObject();
		cacheObject.setObject(object);
		cacheObject.setLastAccessedTimestamp(System.currentTimeMillis());
		
		synchronized (lock) {
			cache.put(primaryKey, cacheObject);
		}
	}
	
	//======================================================
	//Remove cached object from the cache
	//======================================================
	public void removeFromCache(int primaryKey){
		synchronized (lock) {
			cache.remove(primaryKey);
		}
	}
	
	//======================================================
	//Remove all cached object from the cache
	//======================================================
	public void removeAllObjects(){
		System.out.println("Clearing all cached objects for the table : " + tableName);
		synchronized (lock) {
			cache.clear();
		}
	}
	
	//======================================================
	//Evict all entries which have not being accessed for a long time
	//======================================================
	public void evictExpiredEntries(){
		synchronized (lock) {
			long now = System.currentTimeMillis();
			
			Set<Integer> primaryKeys = cache.keySet();
			List<Integer> deleteKeys = new ArrayList<>();

			//Iterate through all cached objects within a cache
			for(Integer primaryKey : primaryKeys){
				CacheObject object = cache.get(primaryKey);
				
				//Identify expired cached objects
				if(now - (Constants.TIME_TO_LIVE_IN_SECONDS * 1000) > object.getLastAccessedTimestamp()){
					deleteKeys.add(primaryKey);
				}
			}
			
			//Delete expired cached entries
			for (Integer deleteKey : deleteKeys) {
				cache.remove(deleteKey);
			}
		}//synchronized (lock)
	}
	
	public int getSize(){
		return cache.size();
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
}
